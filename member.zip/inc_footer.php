</div>  

<footer class="footer mt-5 py-3 bg-primary">
    <div class="container d-flex gap-1">
        <img src="imeges/icon.svg" style="width:2rem" class="me-2">
        <div class="d-flex flex-column">
            <span class="text-bg-primary">화이트 햇 스쿨 웹 침투테스트 모의해킹 </span>
            <span class="text-bg-primary">대표자: 스파이더맨</span>
        </div>
    </div>

</footer>
</body>
</html>